project(
  'owl-file-manager',
  'cpp',
  version: '0.1.0',
  license: 'GPL-3.0-or-later',
  meson_version: '>=0.59.0',
  default_options: [
    'cpp_std=c++17',
    'warning_level=2',
    'werror=false',
  ],
)

qt6 = import('qt6')
qt_core = dependency('qt6', modules: ['Core'])
qt_gui = dependency('qt6', modules: ['Gui'])
qt_qml = dependency('qt6', modules: ['Qml'])
qt_quick = dependency('qt6', modules: ['Quick'])

resources = qt6.compile_resources(
  name: 'owl-resources',
  sources: 'src/owl.qrc',
)
moc_sources = qt6.preprocess(
  moc_headers: 'src/filemodel.h',
)

executable(
  'owl-file-manager',
  [
    'src/main.cpp',
    'src/filemodel.cpp',
    'src/filemodel.h',
    'src/fileiconprovider.cpp',
    'src/fileiconprovider.h',
    resources,
    moc_sources,
  ],
  dependencies: [qt_core, qt_gui, qt_qml, qt_quick],
  install: true,
)

install_data(
  'data/owl-file-manager.desktop',
  install_dir: get_option('datadir') / 'applications',
)

install_data(
  'icons/icon_owlfm.svg',
  install_dir: get_option('datadir') / 'icons/hicolor/scalable/apps',
)

install_data(
  'README.md',
  install_dir: get_option('datadir') / 'owl-file-manager',
)

summary(
  {
    'Application': 'Owl File Manager',
    'Version': meson.project_version(),
    'UI toolkit': 'Qt 6 Quick / QML',
  },
  section: 'Build configuration',
)
