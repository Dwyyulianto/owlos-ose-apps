#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
export BUILD_DIR=${BUILD_DIR:-"$ROOT/build/pi-zero-2w-arm64"}
export OUTPUT_DIR=${OUTPUT_DIR:-"$ROOT/dist"}
export BUILD_JOBS=${BUILD_JOBS:-1}
export EXPECTED_ARCH=arm64

exec "$ROOT/packaging/build-deb.sh"
