#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
BUILD_DIR=${BUILD_DIR:-"$ROOT/build"}
OUTPUT_DIR=${OUTPUT_DIR:-"$ROOT/dist"}
VERSION=$(sed -n "s/^[[:space:]]*version: '\\([^']*\\)'.*/\\1/p" "$ROOT/meson.build" | head -n 1)
ARCH=$(dpkg --print-architecture)
BUILD_JOBS=${BUILD_JOBS:-1}
MAINTAINER=${DEB_MAINTAINER:-"Owl File Manager Maintainers <maintainers@example.org>"}

if [ -z "$VERSION" ]; then
    echo "Could not determine package version from meson.build" >&2
    exit 1
fi

if [ -n "${EXPECTED_ARCH:-}" ] && [ "$ARCH" != "$EXPECTED_ARCH" ]; then
    echo "Expected architecture $EXPECTED_ARCH, but this system is $ARCH." >&2
    echo "Build this package on the target architecture." >&2
    exit 1
fi

for tool in meson dpkg dpkg-deb dpkg-shlibdeps; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "Required tool not found: $tool" >&2
        exit 1
    fi
done

mkdir -p "$BUILD_DIR" "$OUTPUT_DIR"
WORK_DIR=$(mktemp -d "$BUILD_DIR/deb-package.XXXXXX")
trap 'rm -rf "$WORK_DIR"' EXIT HUP INT TERM
PACKAGE_ROOT="$WORK_DIR/package"
CONTROL_DIR="$WORK_DIR/control"
STAGE="$PACKAGE_ROOT"

mkdir -p "$PACKAGE_ROOT/DEBIAN" "$CONTROL_DIR/debian"

if [ -f "$BUILD_DIR/meson-private/coredata.dat" ]; then
    meson setup --reconfigure "$BUILD_DIR" "$ROOT" --prefix=/usr
else
    meson setup "$BUILD_DIR" "$ROOT" --prefix=/usr
fi
meson compile -C "$BUILD_DIR" --jobs "$BUILD_JOBS"
meson install -C "$BUILD_DIR" --destdir "$STAGE"

cat > "$CONTROL_DIR/debian/control" <<EOF
Source: owl-file-manager
Section: utils
Priority: optional
Maintainer: $MAINTAINER

Package: owl-file-manager
Architecture: $ARCH
Description: Lightweight Qt 6 file manager
 Browse and manage files with a Qt Quick desktop interface.
EOF

SHLIBS=$(cd "$CONTROL_DIR" && dpkg-shlibdeps -O -e "$STAGE/usr/bin/owl-file-manager")
case "$SHLIBS" in
    shlibs:Depends=*) ;;
    *)
        echo "Could not determine shared-library dependencies: $SHLIBS" >&2
        exit 1
        ;;
esac
SHLIBS=${SHLIBS#shlibs:Depends=}

cat > "$PACKAGE_ROOT/DEBIAN/control" <<EOF
Package: owl-file-manager
Version: $VERSION
Section: utils
Priority: optional
Architecture: $ARCH
Maintainer: $MAINTAINER
Depends: $SHLIBS, libqt6svg6, qml6-module-qtquick-controls, qml6-module-qtquick-layouts, qt6-wayland
Description: Lightweight Qt 6 file manager
 Browse and manage files with a Qt Quick desktop interface.
EOF

OUTPUT="$OUTPUT_DIR/owl-file-manager_${VERSION}_${ARCH}.deb"
dpkg-deb --root-owner-group --build "$PACKAGE_ROOT" "$OUTPUT"
echo "Created Debian package: $OUTPUT"
