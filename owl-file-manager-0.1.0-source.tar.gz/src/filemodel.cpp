#include "filemodel.h"

#include <QClipboard>
#include <QCryptographicHash>
#include <QDateTime>
#include <QDesktopServices>
#include <QDir>
#include <QFileInfo>
#include <QGuiApplication>
#include <QLocale>
#include <QMimeDatabase>
#include <QMimeType>
#include <QProcess>
#include <QSettings>
#include <QStandardPaths>
#include <QUrl>

#include <algorithm>

FileModel::FileModel(QObject *parent)
    : QAbstractListModel(parent)
{
    QSettings settings(QStringLiteral("OwlOS"), QStringLiteral("OwlFileManager"));
    m_rootLockEnabled = settings.value(QStringLiteral("rootLockEnabled"), true).toBool();
    m_rootPasswordHash = settings.value(QStringLiteral("rootPasswordHash")).toString();
    if (m_rootPasswordHash.isEmpty()) {
        m_rootPasswordHash = hashPassword(QStringLiteral("owl123"));
        settings.setValue(QStringLiteral("rootPasswordHash"), m_rootPasswordHash);
    }
    setPath(QDir::homePath());
}

int FileModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : m_filteredEntries.size();
}

QVariant FileModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_filteredEntries.size())
        return {};

    const QFileInfo &entry = m_filteredEntries.at(index.row());
    switch (role) {
    case NameRole:
        return entry.fileName();
    case FilePathRole:
        return entry.absoluteFilePath();
    case IsDirectoryRole:
        return entry.isDir();
    case SizeRole:
        return entry.isDir() ? QStringLiteral("—") : QLocale().formattedDataSize(entry.size());
    case ModifiedRole:
        return QLocale().toString(entry.lastModified(), QLocale::ShortFormat);
    case IconSourceRole:
        return QStringLiteral("image://fileicon/") + QString::fromUtf8(QUrl::toPercentEncoding(entry.absoluteFilePath()));
    case PermissionsRole: {
        QFile::Permissions p = entry.permissions();
        QString perms;
        perms += (entry.isDir() ? QLatin1Char('d') : QLatin1Char('-'));
        perms += (p & QFile::ReadUser) ? QLatin1Char('r') : QLatin1Char('-');
        perms += (p & QFile::WriteUser) ? QLatin1Char('w') : QLatin1Char('-');
        perms += (p & QFile::ExeUser) ? QLatin1Char('x') : QLatin1Char('-');
        perms += (p & QFile::ReadGroup) ? QLatin1Char('r') : QLatin1Char('-');
        perms += (p & QFile::WriteGroup) ? QLatin1Char('w') : QLatin1Char('-');
        perms += (p & QFile::ExeGroup) ? QLatin1Char('x') : QLatin1Char('-');
        perms += (p & QFile::ReadOther) ? QLatin1Char('r') : QLatin1Char('-');
        perms += (p & QFile::WriteOther) ? QLatin1Char('w') : QLatin1Char('-');
        perms += (p & QFile::ExeOther) ? QLatin1Char('x') : QLatin1Char('-');
        return perms;
    }
    case ExtensionRole:
        return entry.suffix().toLower();
    default:
        return {};
    }
}

QHash<int, QByteArray> FileModel::roleNames() const
{
    return {
        {NameRole, "name"},
        {FilePathRole, "filePath"},
        {IsDirectoryRole, "isDirectory"},
        {SizeRole, "size"},
        {ModifiedRole, "modified"},
        {IconSourceRole, "iconSource"},
        {PermissionsRole, "permissions"},
        {ExtensionRole, "extension"},
    };
}

QString FileModel::path() const
{
    return m_path;
}

QString FileModel::errorMessage() const
{
    return m_errorMessage;
}

bool FileModel::showHiddenFiles() const
{
    return m_showHiddenFiles;
}

QString FileModel::filterText() const
{
    return m_filterText;
}

int FileModel::sortMode() const
{
    return m_sortMode;
}

bool FileModel::sortAscending() const
{
    return m_sortAscending;
}

bool FileModel::canGoBack() const
{
    return m_historyIndex > 0;
}

bool FileModel::canGoForward() const
{
    return m_historyIndex >= 0 && m_historyIndex < (m_history.size() - 1);
}

int FileModel::itemCount() const
{
    return m_filteredEntries.size();
}

int FileModel::folderCount() const
{
    return m_folderCount;
}

int FileModel::fileCount() const
{
    return m_fileCount;
}

#include <sys/statvfs.h>

QString FileModel::storageFreeSpace() const
{
    const QString targetPath = m_path.isEmpty() ? QDir::homePath() : m_path;
    struct statvfs stat;
    if (statvfs(targetPath.toLocal8Bit().constData(), &stat) == 0) {
        const quint64 freeBytes = static_cast<quint64>(stat.f_bavail) * stat.f_frsize;
        return QLocale().formattedDataSize(freeBytes) + QStringLiteral(" free");
    }
    return QString();
}

bool FileModel::hasClipboard() const
{
    return !m_clipboardPath.isEmpty() && QFileInfo::exists(m_clipboardPath);
}

QString FileModel::clipboardOperation() const
{
    return m_clipboardOp;
}

bool FileModel::rootLockEnabled() const
{
    return m_rootLockEnabled;
}

bool FileModel::isRootUnlocked() const
{
    return m_isRootUnlocked;
}

void FileModel::setRootLockEnabled(bool enabled)
{
    if (m_rootLockEnabled == enabled)
        return;
    m_rootLockEnabled = enabled;
    QSettings settings(QStringLiteral("OwlOS"), QStringLiteral("OwlFileManager"));
    settings.setValue(QStringLiteral("rootLockEnabled"), m_rootLockEnabled);
    emit rootLockEnabledChanged();
    emit rootUnlockStatusChanged();
}

bool FileModel::unlockRoot(const QString &password)
{
    if (hashPassword(password) == m_rootPasswordHash) {
        m_isRootUnlocked = true;
        emit rootUnlockStatusChanged();
        return true;
    }
    return false;
}

void FileModel::lockRoot()
{
    m_isRootUnlocked = false;
    emit rootUnlockStatusChanged();
    if (isPathProtected(m_path)) {
        setPath(QDir::homePath());
    }
}

bool FileModel::changeRootPassword(const QString &oldPassword, const QString &newPassword)
{
    if (hashPassword(oldPassword) != m_rootPasswordHash)
        return false;
    if (newPassword.trimmed().isEmpty())
        return false;

    m_rootPasswordHash = hashPassword(newPassword.trimmed());
    QSettings settings(QStringLiteral("OwlOS"), QStringLiteral("OwlFileManager"));
    settings.setValue(QStringLiteral("rootPasswordHash"), m_rootPasswordHash);
    return true;
}

bool FileModel::isPathProtected(const QString &path) const
{
    QString resolvedPath = QDir::cleanPath(QFileInfo(path).absoluteFilePath());
    QStringList unresolvedComponents;
    while (!QFileInfo::exists(resolvedPath)) {
        const QFileInfo component(resolvedPath);
        if (component.fileName().isEmpty())
            break;
        unresolvedComponents.prepend(component.fileName());
        resolvedPath = component.dir().absolutePath();
    }

    resolvedPath = QFileInfo(resolvedPath).canonicalFilePath();
    if (resolvedPath.isEmpty())
        resolvedPath = QDir::cleanPath(QFileInfo(path).absoluteFilePath());
    for (const QString &component : unresolvedComponents)
        resolvedPath = QDir(resolvedPath).filePath(component);
    resolvedPath = QDir::cleanPath(resolvedPath);

    const QString homePath = QFileInfo(QDir::homePath()).canonicalFilePath();
    const QString home = homePath.isEmpty() ? QDir::cleanPath(QDir::homePath()) : homePath;
    const QString relativePath = QDir(home).relativeFilePath(resolvedPath);
    const bool insideHome = relativePath != QStringLiteral("..")
        && !relativePath.startsWith(QStringLiteral("../"))
        && !QDir::isAbsolutePath(relativePath);
    const QString tempPath = QFileInfo(QStringLiteral("/tmp")).canonicalFilePath();
    const QString temp = tempPath.isEmpty() ? QStringLiteral("/tmp") : tempPath;
    const QString relativeToTemp = QDir(temp).relativeFilePath(resolvedPath);
    const bool insideTemp = relativeToTemp != QStringLiteral("..")
        && !relativeToTemp.startsWith(QStringLiteral("../"))
        && !QDir::isAbsolutePath(relativeToTemp);

    return !insideHome && !insideTemp;
}

QString FileModel::hashPassword(const QString &password)
{
    return QString::fromLatin1(QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256).toHex());
}

void FileModel::setPath(const QString &path)
{
    QString requestedPath = path;
    if (requestedPath.startsWith(QStringLiteral("file://")))
        requestedPath = QUrl(requestedPath).toLocalFile();
    if (requestedPath.isEmpty())
        requestedPath = QDir::homePath();

    const QFileInfo target(requestedPath);
    if (target.exists() && target.isFile())
        requestedPath = target.dir().absolutePath();
    const QString absolutePath = QDir::cleanPath(QFileInfo(requestedPath).absoluteFilePath());

    if (isPathProtected(absolutePath) && m_rootLockEnabled && !m_isRootUnlocked) {
        emit requestRootPassword(absolutePath);
        return;
    }

    if (!QFileInfo(absolutePath).exists() && absolutePath.startsWith(QDir::homePath())) {
        QDir().mkpath(absolutePath);
    }

    if (!QFileInfo(absolutePath).isDir() || !QFileInfo(absolutePath).isReadable()) {
        const QString message = QStringLiteral("Cannot open folder: %1").arg(absolutePath);
        if (m_errorMessage != message) {
            m_errorMessage = message;
            emit errorMessageChanged();
        }
        return;
    }

    if (!m_errorMessage.isEmpty()) {
        m_errorMessage.clear();
        emit errorMessageChanged();
    }

    if (m_path != absolutePath) {
        m_path = absolutePath;
        // Truncate history forward if we navigated to a new path
        while (m_history.size() > m_historyIndex + 1)
            m_history.removeLast();
        m_history.append(m_path);
        m_historyIndex = m_history.size() - 1;

        emit pathChanged();
        emit historyChanged();
    }

    loadDirectory(false);
}

void FileModel::setShowHiddenFiles(bool show)
{
    if (m_showHiddenFiles == show)
        return;
    m_showHiddenFiles = show;
    emit showHiddenFilesChanged();
    applyFilterAndSort();
}

void FileModel::setFilterText(const QString &text)
{
    if (m_filterText == text)
        return;
    m_filterText = text.trimmed();
    emit filterTextChanged();
    applyFilterAndSort();
}

void FileModel::setSortMode(int mode)
{
    if (m_sortMode == mode)
        return;
    m_sortMode = mode;
    emit sortModeChanged();
    applyFilterAndSort();
}

void FileModel::setSortAscending(bool ascending)
{
    if (m_sortAscending == ascending)
        return;
    m_sortAscending = ascending;
    emit sortAscendingChanged();
    applyFilterAndSort();
}

void FileModel::toggleSortOrder()
{
    setSortAscending(!m_sortAscending);
}

void FileModel::goUp()
{
    const QDir current(m_path);
    if (!current.isRoot()) {
        setPath(current.filePath(QStringLiteral("..")));
    }
}

void FileModel::goBack()
{
    if (canGoBack()) {
        const QString targetPath = m_history.at(m_historyIndex - 1);
        if (isPathProtected(targetPath) && m_rootLockEnabled && !m_isRootUnlocked) {
            emit requestRootPassword(targetPath);
            return;
        }
        m_historyIndex--;
        m_path = m_history.at(m_historyIndex);
        emit pathChanged();
        emit historyChanged();
        loadDirectory(false);
    }
}

void FileModel::goForward()
{
    if (canGoForward()) {
        const QString targetPath = m_history.at(m_historyIndex + 1);
        if (isPathProtected(targetPath) && m_rootLockEnabled && !m_isRootUnlocked) {
            emit requestRootPassword(targetPath);
            return;
        }
        m_historyIndex++;
        m_path = m_history.at(m_historyIndex);
        emit pathChanged();
        emit historyChanged();
        loadDirectory(false);
    }
}

void FileModel::goHome()
{
    setPath(QDir::homePath());
}

void FileModel::refresh()
{
    loadDirectory(false);
}

void FileModel::loadDirectory(bool addToHistory)
{
    Q_UNUSED(addToHistory);
    QDir directory(m_path);
    m_rawEntries = directory.entryInfoList(
        QDir::AllEntries | QDir::NoDotAndDotDot | QDir::Hidden | QDir::System,
        QDir::DirsFirst | QDir::IgnoreCase | QDir::Name);

    applyFilterAndSort();
}

void FileModel::applyFilterAndSort()
{
    beginResetModel();
    m_filteredEntries.clear();
    m_folderCount = 0;
    m_fileCount = 0;

    for (const QFileInfo &entry : m_rawEntries) {
        if (!m_showHiddenFiles && entry.fileName().startsWith(QLatin1Char('.')))
            continue;
        if (!m_filterText.isEmpty() && !entry.fileName().contains(m_filterText, Qt::CaseInsensitive))
            continue;

        m_filteredEntries.append(entry);
        if (entry.isDir())
            m_folderCount++;
        else
            m_fileCount++;
    }

    std::sort(m_filteredEntries.begin(), m_filteredEntries.end(), [this](const QFileInfo &a, const QFileInfo &b) {
        if (a.isDir() != b.isDir())
            return a.isDir(); // Folders always first

        int cmp = 0;
        switch (m_sortMode) {
        case SortBySize:
            if (a.size() != b.size())
                return m_sortAscending ? (a.size() < b.size()) : (a.size() > b.size());
            break;
        case SortByDate:
            if (a.lastModified() != b.lastModified())
                return m_sortAscending ? (a.lastModified() < b.lastModified()) : (a.lastModified() > b.lastModified());
            break;
        case SortByType:
            cmp = QString::compare(a.suffix(), b.suffix(), Qt::CaseInsensitive);
            if (cmp != 0)
                return m_sortAscending ? (cmp < 0) : (cmp > 0);
            break;
        case SortByName:
        default:
            break;
        }

        cmp = QString::compare(a.fileName(), b.fileName(), Qt::CaseInsensitive);
        return m_sortAscending ? (cmp < 0) : (cmp > 0);
    });

    endResetModel();
    emit itemCountChanged();
}

bool FileModel::openItem(const QString &path)
{
    const QFileInfo fi(path);
    if (!fi.exists())
        return false;

    if (fi.isDir()) {
        setPath(path);
        return true;
    }
    return QDesktopServices::openUrl(QUrl::fromLocalFile(path));
}

bool FileModel::createFolder(const QString &name)
{
    if (name.trimmed().isEmpty())
        return false;

    QDir dir(m_path);
    if (dir.mkdir(name.trimmed())) {
        refresh();
        return true;
    }
    m_errorMessage = QStringLiteral("Failed to create folder: %1").arg(name);
    emit errorMessageChanged();
    return false;
}

bool FileModel::createFile(const QString &name)
{
    if (name.trimmed().isEmpty())
        return false;

    const QString filePath = QDir(m_path).filePath(name.trimmed());
    if (QFileInfo::exists(filePath)) {
        m_errorMessage = QStringLiteral("File already exists: %1").arg(name);
        emit errorMessageChanged();
        return false;
    }

    QFile file(filePath);
    if (file.open(QIODevice::WriteOnly)) {
        file.close();
        refresh();
        return true;
    }
    m_errorMessage = QStringLiteral("Failed to create file: %1").arg(name);
    emit errorMessageChanged();
    return false;
}

bool FileModel::renameItem(const QString &oldPath, const QString &newName)
{
    if (newName.trimmed().isEmpty())
        return false;

    const QFileInfo fi(oldPath);
    if (!fi.exists())
        return false;

    const QString newPath = fi.dir().filePath(newName.trimmed());
    if (QFile::rename(oldPath, newPath)) {
        refresh();
        return true;
    }
    m_errorMessage = QStringLiteral("Failed to rename to: %1").arg(newName);
    emit errorMessageChanged();
    return false;
}

bool FileModel::deleteItem(const QString &path)
{
    const QFileInfo fi(path);
    if (!fi.exists())
        return false;

    if (QFile::moveToTrash(path)) {
        refresh();
        return true;
    }

    bool success = false;
    if (fi.isDir()) {
        success = QDir(path).removeRecursively();
    } else {
        success = QFile::remove(path);
    }

    if (success) {
        refresh();
        return true;
    }

    m_errorMessage = QStringLiteral("Failed to delete: %1").arg(fi.fileName());
    emit errorMessageChanged();
    return false;
}

void FileModel::copyItem(const QString &path)
{
    m_clipboardPath = path;
    m_clipboardOp = QStringLiteral("copy");
    if (QClipboard *clipboard = QGuiApplication::clipboard())
        clipboard->setText(path);
    emit clipboardChanged();
}

void FileModel::cutItem(const QString &path)
{
    m_clipboardPath = path;
    m_clipboardOp = QStringLiteral("cut");
    if (QClipboard *clipboard = QGuiApplication::clipboard())
        clipboard->setText(path);
    emit clipboardChanged();
}

QString FileModel::makeUniquePath(const QString &destinationDir, const QString &baseName, const QString &suffix, bool isDir) const
{
    QString dest = QDir(destinationDir).filePath(suffix.isEmpty() || isDir ? baseName : (baseName + QLatin1Char('.') + suffix));
    if (!QFileInfo::exists(dest))
        return dest;

    int counter = 1;
    while (true) {
        QString copyName = QStringLiteral("%1 (copy %2)").arg(baseName).arg(counter);
        if (counter == 1)
            copyName = QStringLiteral("%1 (copy)").arg(baseName);

        dest = QDir(destinationDir).filePath(suffix.isEmpty() || isDir ? copyName : (copyName + QLatin1Char('.') + suffix));
        if (!QFileInfo::exists(dest))
            return dest;
        counter++;
    }
}

bool FileModel::pasteItem()
{
    if (m_clipboardPath.isEmpty() || !QFileInfo::exists(m_clipboardPath)) {
        m_errorMessage = QStringLiteral("Clipboard is empty or file no longer exists");
        emit errorMessageChanged();
        return false;
    }

    const QFileInfo src(m_clipboardPath);
    QString dest = QDir(m_path).filePath(src.fileName());

    if (m_clipboardOp == QStringLiteral("cut")) {
        if (src.absolutePath() == m_path)
            return true; // same location, do nothing

        if (QFile::rename(m_clipboardPath, dest)) {
            m_clipboardPath.clear();
            m_clipboardOp.clear();
            emit clipboardChanged();
            refresh();
            return true;
        }
    } else {
        // Copy operation
        if (QFileInfo::exists(dest)) {
            dest = makeUniquePath(m_path, src.completeBaseName(), src.suffix(), src.isDir());
        }
        if (copyRecursively(m_clipboardPath, dest)) {
            refresh();
            return true;
        }
    }

    m_errorMessage = QStringLiteral("Failed to paste %1").arg(src.fileName());
    emit errorMessageChanged();
    return false;
}

bool FileModel::duplicateItem(const QString &path)
{
    const QFileInfo src(path);
    if (!src.exists())
        return false;

    const QString dest = makeUniquePath(src.dir().absolutePath(), src.completeBaseName(), src.suffix(), src.isDir());
    if (copyRecursively(path, dest)) {
        refresh();
        return true;
    }
    m_errorMessage = QStringLiteral("Failed to duplicate %1").arg(src.fileName());
    emit errorMessageChanged();
    return false;
}

bool FileModel::copyRecursively(const QString &srcPath, const QString &dstPath)
{
    const QFileInfo srcInfo(srcPath);
    if (srcInfo.isDir()) {
        QDir dstDir(dstPath);
        if (!dstDir.exists() && !QDir().mkpath(dstPath))
            return false;
        const QDir srcDir(srcPath);
        const QStringList entries = srcDir.entryList(QDir::AllEntries | QDir::NoDotAndDotDot | QDir::Hidden | QDir::System);
        for (const QString &entry : entries) {
            const QString subSrc = srcPath + QLatin1Char('/') + entry;
            const QString subDst = dstPath + QLatin1Char('/') + entry;
            if (!copyRecursively(subSrc, subDst))
                return false;
        }
        return true;
    }
    return QFile::copy(srcPath, dstPath);
}

QVariantMap FileModel::getItemProperties(const QString &path) const
{
    const QFileInfo fi(path.isEmpty() ? m_path : path);
    QVariantMap map;
    map[QStringLiteral("name")] = fi.fileName().isEmpty() ? fi.absoluteFilePath() : fi.fileName();
    map[QStringLiteral("path")] = fi.absoluteFilePath();
    map[QStringLiteral("isDir")] = fi.isDir();
    map[QStringLiteral("size")] = fi.isDir() ? QStringLiteral("-") : QLocale().formattedDataSize(fi.size());
    map[QStringLiteral("rawSize")] = fi.size();
    map[QStringLiteral("created")] = QLocale().toString(fi.birthTime().isValid() ? fi.birthTime() : fi.lastModified(), QLocale::ShortFormat);
    map[QStringLiteral("modified")] = QLocale().toString(fi.lastModified(), QLocale::ShortFormat);

    QMimeDatabase db;
    map[QStringLiteral("type")] = fi.isDir() ? QStringLiteral("Folder") : db.mimeTypeForFile(fi).comment();

    QFile::Permissions p = fi.permissions();
    QString perms;
    perms += (fi.isDir() ? QLatin1Char('d') : QLatin1Char('-'));
    perms += (p & QFile::ReadUser) ? QLatin1Char('r') : QLatin1Char('-');
    perms += (p & QFile::WriteUser) ? QLatin1Char('w') : QLatin1Char('-');
    perms += (p & QFile::ExeUser) ? QLatin1Char('x') : QLatin1Char('-');
    perms += (p & QFile::ReadGroup) ? QLatin1Char('r') : QLatin1Char('-');
    perms += (p & QFile::WriteGroup) ? QLatin1Char('w') : QLatin1Char('-');
    perms += (p & QFile::ExeGroup) ? QLatin1Char('x') : QLatin1Char('-');
    perms += (p & QFile::ReadOther) ? QLatin1Char('r') : QLatin1Char('-');
    perms += (p & QFile::WriteOther) ? QLatin1Char('w') : QLatin1Char('-');
    perms += (p & QFile::ExeOther) ? QLatin1Char('x') : QLatin1Char('-');
    map[QStringLiteral("permissions")] = perms;
    map[QStringLiteral("owner")] = fi.owner();
    map[QStringLiteral("group")] = fi.group();
    return map;
}

QVariantList FileModel::quickPlaces() const
{
    QVariantList list;
    const QString home = QDir::homePath();

    auto addPlace = [&](const QString &name, const QString &path, const QString &iconThemeName) {
        QVariantMap item;
        item[QStringLiteral("name")] = name;
        item[QStringLiteral("path")] = path;
        item[QStringLiteral("iconSource")] = QStringLiteral("image://fileicon/theme:") + iconThemeName;
        list.append(item);
    };

    addPlace(QStringLiteral("Home"), home, QStringLiteral("user-home"));
    addPlace(QStringLiteral("Documents"), home + QStringLiteral("/Documents"), QStringLiteral("folder-documents"));
    addPlace(QStringLiteral("Downloads"), home + QStringLiteral("/Downloads"), QStringLiteral("folder-download"));
    addPlace(QStringLiteral("Pictures"), home + QStringLiteral("/Pictures"), QStringLiteral("folder-pictures"));
    addPlace(QStringLiteral("Music"), home + QStringLiteral("/Music"), QStringLiteral("folder-music"));
    addPlace(QStringLiteral("Videos"), home + QStringLiteral("/Videos"), QStringLiteral("folder-videos"));
    addPlace(QStringLiteral("Root (/)"), QStringLiteral("/"), QStringLiteral("drive-harddisk"));

    return list;
}

void FileModel::openTerminal(const QString &targetPath)
{
    const QString dir = targetPath.isEmpty() ? m_path : targetPath;
    const QStringList terminals = {
        QStringLiteral("xdg-terminal-exec"),
        QStringLiteral("x-terminal-emulator"),
        QStringLiteral("gnome-terminal"),
        QStringLiteral("konsole"),
        QStringLiteral("xfce4-terminal"),
        QStringLiteral("xterm")
    };
    for (const QString &term : terminals) {
        if (!QStandardPaths::findExecutable(term).isEmpty()) {
            QProcess::startDetached(term, {}, dir);
            return;
        }
    }
}
