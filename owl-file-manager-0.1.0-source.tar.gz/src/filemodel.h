#pragma once

#include <QAbstractListModel>
#include <QFileInfo>
#include <QList>
#include <QString>
#include <QStringList>
#include <QVariantList>
#include <QVariantMap>

class FileModel final : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(QString path READ path WRITE setPath NOTIFY pathChanged)
    Q_PROPERTY(QString errorMessage READ errorMessage NOTIFY errorMessageChanged)
    Q_PROPERTY(bool showHiddenFiles READ showHiddenFiles WRITE setShowHiddenFiles NOTIFY showHiddenFilesChanged)
    Q_PROPERTY(QString filterText READ filterText WRITE setFilterText NOTIFY filterTextChanged)
    Q_PROPERTY(int sortMode READ sortMode WRITE setSortMode NOTIFY sortModeChanged)
    Q_PROPERTY(bool sortAscending READ sortAscending WRITE setSortAscending NOTIFY sortAscendingChanged)
    Q_PROPERTY(bool canGoBack READ canGoBack NOTIFY historyChanged)
    Q_PROPERTY(bool canGoForward READ canGoForward NOTIFY historyChanged)
    Q_PROPERTY(int itemCount READ itemCount NOTIFY itemCountChanged)
    Q_PROPERTY(int folderCount READ folderCount NOTIFY itemCountChanged)
    Q_PROPERTY(int fileCount READ fileCount NOTIFY itemCountChanged)
    Q_PROPERTY(QString storageFreeSpace READ storageFreeSpace NOTIFY pathChanged)
    Q_PROPERTY(bool hasClipboard READ hasClipboard NOTIFY clipboardChanged)
    Q_PROPERTY(QString clipboardOperation READ clipboardOperation NOTIFY clipboardChanged)
    Q_PROPERTY(bool rootLockEnabled READ rootLockEnabled WRITE setRootLockEnabled NOTIFY rootLockEnabledChanged)
    Q_PROPERTY(bool isRootUnlocked READ isRootUnlocked NOTIFY rootUnlockStatusChanged)

public:
    enum Roles {
        NameRole = Qt::UserRole + 1,
        FilePathRole,
        IsDirectoryRole,
        SizeRole,
        ModifiedRole,
        IconSourceRole,
        PermissionsRole,
        ExtensionRole,
    };
    Q_ENUM(Roles)

    enum SortMode {
        SortByName = 0,
        SortBySize = 1,
        SortByDate = 2,
        SortByType = 3,
    };
    Q_ENUM(SortMode)

    explicit FileModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    QString path() const;
    QString errorMessage() const;
    bool showHiddenFiles() const;
    QString filterText() const;
    int sortMode() const;
    bool sortAscending() const;
    bool canGoBack() const;
    bool canGoForward() const;
    int itemCount() const;
    int folderCount() const;
    int fileCount() const;
    QString storageFreeSpace() const;
    bool hasClipboard() const;
    QString clipboardOperation() const;

    bool rootLockEnabled() const;
    bool isRootUnlocked() const;

    Q_INVOKABLE void setPath(const QString &path);
    Q_INVOKABLE void setShowHiddenFiles(bool show);
    Q_INVOKABLE void setFilterText(const QString &text);
    Q_INVOKABLE void setSortMode(int mode);
    Q_INVOKABLE void setSortAscending(bool ascending);
    Q_INVOKABLE void toggleSortOrder();

    Q_INVOKABLE void setRootLockEnabled(bool enabled);
    Q_INVOKABLE bool unlockRoot(const QString &password);
    Q_INVOKABLE void lockRoot();
    Q_INVOKABLE bool changeRootPassword(const QString &oldPassword, const QString &newPassword);
    Q_INVOKABLE bool isPathProtected(const QString &path) const;

    Q_INVOKABLE void goUp();
    Q_INVOKABLE void goBack();
    Q_INVOKABLE void goForward();
    Q_INVOKABLE void goHome();
    Q_INVOKABLE void refresh();

    Q_INVOKABLE bool openItem(const QString &path);
    Q_INVOKABLE bool createFolder(const QString &name);
    Q_INVOKABLE bool createFile(const QString &name);
    Q_INVOKABLE bool renameItem(const QString &oldPath, const QString &newName);
    Q_INVOKABLE bool deleteItem(const QString &path);
    Q_INVOKABLE void copyItem(const QString &path);
    Q_INVOKABLE void cutItem(const QString &path);
    Q_INVOKABLE bool pasteItem();
    Q_INVOKABLE bool duplicateItem(const QString &path);
    Q_INVOKABLE QVariantMap getItemProperties(const QString &path) const;
    Q_INVOKABLE QVariantList quickPlaces() const;
    Q_INVOKABLE void openTerminal(const QString &targetPath = QString());

signals:
    void pathChanged();
    void errorMessageChanged();
    void showHiddenFilesChanged();
    void filterTextChanged();
    void sortModeChanged();
    void sortAscendingChanged();
    void historyChanged();
    void itemCountChanged();
    void clipboardChanged();
    void rootLockEnabledChanged();
    void rootUnlockStatusChanged();
    void requestRootPassword(const QString &targetPath);

private:
    void loadDirectory(bool addToHistory = true);
    void applyFilterAndSort();
    static bool copyRecursively(const QString &srcPath, const QString &dstPath);
    QString makeUniquePath(const QString &destinationDir, const QString &baseName, const QString &suffix, bool isDir) const;
    static QString hashPassword(const QString &password);

    QString m_path;
    QString m_errorMessage;
    bool m_showHiddenFiles = false;
    QString m_filterText;
    int m_sortMode = SortByName;
    bool m_sortAscending = true;

    bool m_rootLockEnabled = true;
    bool m_isRootUnlocked = false;
    QString m_rootPasswordHash;

    QStringList m_history;
    int m_historyIndex = -1;

    QString m_clipboardPath;
    QString m_clipboardOp;

    QList<QFileInfo> m_rawEntries;
    QList<QFileInfo> m_filteredEntries;
    int m_folderCount = 0;
    int m_fileCount = 0;
};
