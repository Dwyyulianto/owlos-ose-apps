#include "fileiconprovider.h"
#include "filemodel.h"

#include <QCommandLineParser>
#include <QDir>
#include <QGuiApplication>
#include <QIcon>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QUrl>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QGuiApplication::setApplicationName(QStringLiteral("Owl File Manager"));
    QGuiApplication::setOrganizationName(QStringLiteral("Owl OS"));
    QGuiApplication::setDesktopFileName(QStringLiteral("owl-file-manager"));
    app.setWindowIcon(QIcon(QStringLiteral(":/icons/icon_owlfm.svg")));

    QStringList iconSearchPaths = QIcon::themeSearchPaths();
    if (!iconSearchPaths.contains(QStringLiteral("/usr/share/icons")))
        iconSearchPaths.prepend(QStringLiteral("/usr/share/icons"));
    if (!iconSearchPaths.contains(QStringLiteral("/usr/local/share/icons")))
        iconSearchPaths.prepend(QStringLiteral("/usr/local/share/icons"));
    QIcon::setThemeSearchPaths(iconSearchPaths);

    if (QIcon::themeName().isEmpty() || QIcon::themeName() == QStringLiteral("hicolor")) {
        if (QDir(QStringLiteral("/usr/share/icons/Adwaita")).exists())
            QIcon::setThemeName(QStringLiteral("Adwaita"));
    }

    QCommandLineParser parser;
    parser.setApplicationDescription(QStringLiteral("Browse and manage files"));
    parser.addHelpOption();
    parser.addPositionalArgument(QStringLiteral("path"), QStringLiteral("Folder to open"), QStringLiteral("[path]"));
    parser.process(app);

    FileModel fileModel;
    const QStringList positionalArguments = parser.positionalArguments();
    const QString initialPath = positionalArguments.isEmpty() ? QString() : positionalArguments.constFirst();

    QQmlApplicationEngine engine;
    engine.addImageProvider(QStringLiteral("fileicon"), new FileIconProvider);
    engine.rootContext()->setContextProperty(QStringLiteral("fileModel"), &fileModel);
    engine.load(QUrl(QStringLiteral("qrc:/qml/Main.qml")));
    if (engine.rootObjects().isEmpty())
        return 1;
    if (!initialPath.isEmpty())
        fileModel.setPath(initialPath);

    return app.exec();
}
