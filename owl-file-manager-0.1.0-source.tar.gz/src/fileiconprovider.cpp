#include "fileiconprovider.h"

#include <QDir>
#include <QFileInfo>
#include <QIcon>
#include <QMimeDatabase>
#include <QMimeType>
#include <QPainter>
#include <QUrl>

FileIconProvider::FileIconProvider()
    : QQuickImageProvider(QQuickImageProvider::Pixmap)
{
}

QPixmap FileIconProvider::requestPixmap(const QString &id, QSize *size, const QSize &requestedSize)
{
    const int w = requestedSize.width() > 0 ? requestedSize.width() : 48;
    const int h = requestedSize.height() > 0 ? requestedSize.height() : 48;
    const QSize targetSize(w, h);

    if (size)
        *size = targetSize;

    // Check if id requests a theme icon directly: "theme:<iconName>"
    if (id.startsWith(QLatin1String("theme:"))) {
        const QString themeName = id.mid(6);
        QIcon themeIcon = QIcon::fromTheme(themeName);
        if (themeIcon.isNull())
            themeIcon = QIcon::fromTheme(QStringLiteral("folder"));
        QPixmap pm = themeIcon.pixmap(targetSize);
        if (!pm.isNull())
            return pm;
    }

    const QString path = QUrl::fromPercentEncoding(id.toUtf8());
    const QFileInfo fi(path);

    QIcon icon;
    const bool isLikelyFolder = fi.isDir()
        || path.endsWith(QLatin1Char('/'))
        || (!fi.exists() && (path.contains(QLatin1String("Documents"))
                             || path.contains(QLatin1String("Downloads"))
                             || path.contains(QLatin1String("Pictures"))
                             || path.contains(QLatin1String("Music"))
                             || path.contains(QLatin1String("Videos"))));

    if (isLikelyFolder) {
        if (path == QDir::homePath()) {
            icon = QIcon::fromTheme(QStringLiteral("user-home"));
        } else if (path.endsWith(QLatin1String("Documents"))) {
            icon = QIcon::fromTheme(QStringLiteral("folder-documents"));
        } else if (path.endsWith(QLatin1String("Downloads"))) {
            icon = QIcon::fromTheme(QStringLiteral("folder-download"));
        } else if (path.endsWith(QLatin1String("Pictures"))) {
            icon = QIcon::fromTheme(QStringLiteral("folder-pictures"));
        } else if (path.endsWith(QLatin1String("Music"))) {
            icon = QIcon::fromTheme(QStringLiteral("folder-music"));
        } else if (path.endsWith(QLatin1String("Videos"))) {
            icon = QIcon::fromTheme(QStringLiteral("folder-videos"));
        } else if (path == QStringLiteral("/")) {
            icon = QIcon::fromTheme(QStringLiteral("drive-harddisk"));
        }

        if (icon.isNull())
            icon = QIcon::fromTheme(QStringLiteral("folder"));
        if (icon.isNull())
            icon = QIcon::fromTheme(QStringLiteral("inode-directory"));
    } else {
        QMimeDatabase mimeDb;
        QMimeType mime = mimeDb.mimeTypeForFile(fi);

        // 1. Try specific icon name from mime database
        if (QIcon::hasThemeIcon(mime.iconName())) {
            icon = QIcon::fromTheme(mime.iconName());
        }
        // 2. Try generic icon name from mime database
        else if (QIcon::hasThemeIcon(mime.genericIconName())) {
            icon = QIcon::fromTheme(mime.genericIconName());
        }
        // 3. Fallbacks based on common extensions / categories
        else {
            const QString suffix = fi.suffix().toLower();
            if (suffix == QStringLiteral("sh") || suffix == QStringLiteral("bash") || suffix == QStringLiteral("zsh")) {
                icon = QIcon::fromTheme(QStringLiteral("text-x-script"));
            } else if (suffix == QStringLiteral("tar") || suffix == QStringLiteral("gz") || suffix == QStringLiteral("zip") || suffix == QStringLiteral("bz2") || suffix == QStringLiteral("xz") || suffix == QStringLiteral("7z")) {
                icon = QIcon::fromTheme(QStringLiteral("package-x-generic"));
            } else if (suffix == QStringLiteral("png") || suffix == QStringLiteral("jpg") || suffix == QStringLiteral("jpeg") || suffix == QStringLiteral("svg") || suffix == QStringLiteral("gif") || suffix == QStringLiteral("webp")) {
                icon = QIcon::fromTheme(QStringLiteral("image-x-generic"));
            } else if (suffix == QStringLiteral("mp3") || suffix == QStringLiteral("flac") || suffix == QStringLiteral("wav") || suffix == QStringLiteral("ogg") || suffix == QStringLiteral("m4a")) {
                icon = QIcon::fromTheme(QStringLiteral("audio-x-generic"));
            } else if (suffix == QStringLiteral("mp4") || suffix == QStringLiteral("mkv") || suffix == QStringLiteral("avi") || suffix == QStringLiteral("webm") || suffix == QStringLiteral("mov")) {
                icon = QIcon::fromTheme(QStringLiteral("video-x-generic"));
            } else if (suffix == QStringLiteral("pdf") || suffix == QStringLiteral("doc") || suffix == QStringLiteral("docx") || suffix == QStringLiteral("odt")) {
                icon = QIcon::fromTheme(QStringLiteral("x-office-document"));
            } else if (suffix == QStringLiteral("xls") || suffix == QStringLiteral("xlsx") || suffix == QStringLiteral("ods") || suffix == QStringLiteral("csv")) {
                icon = QIcon::fromTheme(QStringLiteral("x-office-spreadsheet"));
            } else if (suffix == QStringLiteral("ppt") || suffix == QStringLiteral("pptx") || suffix == QStringLiteral("odp")) {
                icon = QIcon::fromTheme(QStringLiteral("x-office-presentation"));
            } else if (fi.isExecutable()) {
                icon = QIcon::fromTheme(QStringLiteral("application-x-executable"));
            } else {
                icon = QIcon::fromTheme(QStringLiteral("text-x-generic"));
            }
        }

        if (icon.isNull()) {
            icon = QIcon::fromTheme(QStringLiteral("application-x-generic"));
        }
        if (icon.isNull()) {
            icon = QIcon::fromTheme(QStringLiteral("text-x-generic"));
        }
    }

    QPixmap pixmap = icon.pixmap(targetSize);
    if (!pixmap.isNull())
        return pixmap;

    // Safety fallback: if no theme icon was found, draw a clean vector-style icon
    QPixmap fallback(targetSize);
    fallback.fill(Qt::transparent);
    QPainter painter(&fallback);
    painter.setRenderHint(QPainter::Antialiasing);
    if (isLikelyFolder) {
        painter.setBrush(QColor(0x35, 0x84, 0xe4)); // Modern blue folder
        painter.setPen(Qt::NoPen);
        painter.drawRoundedRect(3, 8, w - 6, h - 11, 4, 4);
        painter.drawRoundedRect(3, 5, (w * 4) / 10, 6, 2, 2);
    } else {
        painter.setBrush(QColor(0xec, 0xf0, 0xf1));
        painter.setPen(QColor(0xbd, 0xc3, 0xc7));
        painter.drawRoundedRect(5, 3, w - 10, h - 6, 3, 3);
        painter.setBrush(QColor(0xbd, 0xc3, 0xc7));
        painter.drawRect(8, 10, w - 16, 2);
        painter.drawRect(8, 14, w - 16, 2);
        painter.drawRect(8, 18, (w * 5) / 10, 2);
    }
    return fallback;
}
