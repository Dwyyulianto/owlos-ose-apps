#pragma once

#include <QQuickImageProvider>

class FileIconProvider final : public QQuickImageProvider
{
public:
    FileIconProvider();
    QPixmap requestPixmap(const QString &id, QSize *size, const QSize &requestedSize) override;
};
