#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)

if [ "$(dpkg --print-architecture)" != "arm64" ]; then
    echo "This installer must be run on an arm64 Raspberry Pi." >&2
    exit 1
fi

if ! command -v apt-get >/dev/null 2>&1; then
    echo "Required tool not found: apt-get" >&2
    exit 1
fi

root_command() {
    if [ "$(id -u)" -eq 0 ]; then
        "$@"
    elif command -v sudo >/dev/null 2>&1; then
        sudo "$@"
    else
        echo "Run as root or install sudo to install packages." >&2
        return 1
    fi
}

root_command apt-get update
root_command apt-get install -y \
    build-essential \
    dpkg-dev \
    meson \
    ninja-build \
    qt6-base-dev \
    qt6-declarative-dev \
    qt6-svg-dev

BUILD_DIR="$ROOT/build/pi-zero-2w-arm64" \
OUTPUT_DIR="$ROOT/dist" \
BUILD_JOBS=1 \
    "$ROOT/packaging/build-pi-zero-2w.sh"

VERSION=$(sed -n "s/^[[:space:]]*version: '\\([^']*\\)'.*/\\1/p" "$ROOT/meson.build" | head -n 1)
if [ -z "$VERSION" ]; then
    echo "Could not determine package version from meson.build" >&2
    exit 1
fi

PACKAGE="$ROOT/dist/owl-file-manager_${VERSION}_arm64.deb"
if [ ! -f "$PACKAGE" ]; then
    echo "Expected package was not created: $PACKAGE" >&2
    exit 1
fi

root_command apt-get install -y "$PACKAGE"
echo "Installed Owl File Manager. Run it from the application menu or with: owl-file-manager"
