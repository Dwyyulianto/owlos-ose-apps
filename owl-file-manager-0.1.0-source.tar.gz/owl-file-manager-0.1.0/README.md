# Owl File Manager

Owl File Manager is a modern, lightweight Qt 6 Quick / QML file manager built for Owl OS and modern Linux desktop environments (Wayland & X11).

![Owl File Manager Icon](icons/icon_owlfm.svg)

## Features

- **Intuitive Navigation**: Back, Forward, Up, Home, and Refresh controls with full history support.
- **Places Sidebar**: Quick access to Home, Documents, Downloads, Pictures, Music, Videos, and Root filesystem.
- **Real-Time Search & Filtering**: Instant substring filter across directory contents.
- **Comprehensive File Management**:
  - Open files directly with system default applications (`QDesktopServices`).
  - Create new folders (`Ctrl+Shift+N`) and new files (`Ctrl+N`).
  - Cut (`Ctrl+X`), Copy (`Ctrl+C`), Paste (`Ctrl+V`), and Duplicate items with automatic collision renaming.
  - Rename items (`F2`).
  - Move to Trash / Delete (`Delete`) with confirmation dialog.
  - File / Folder Properties inspection (permissions, size, type, timestamps, owner/group).
  - Open in terminal context action.
- **Rich Icon Integration**: Automatic freedesktop icon theme resolution (`QMimeDatabase`) for extensions, mime types, and special directory types.
- **Sorting Options**: Sort by Name, Size, Date Modified, or Type (extension) with Ascending/Descending toggle.
- **Hidden Files Toggle**: Easily show or hide dotfiles (`Ctrl+H`).
- **Disk Storage Indicator**: Real-time free disk space indicator for the active volume.

## Build Dependencies

- Meson 0.59 or newer
- Ninja
- C++17 compiler (`g++` or `clang++`)
- Qt 6 packages: Core, Gui, Qml, Quick, Svg

On Debian / Ubuntu:
```sh
sudo apt update
sudo apt install build-essential dpkg-dev meson ninja-build qt6-base-dev qt6-declarative-dev qt6-svg-dev
```

## Build and Run

```sh
meson setup build
meson compile -C build
./build/owl-file-manager [folder]
```

To explicitly force Wayland:
```sh
QT_QPA_PLATFORM=wayland ./build/owl-file-manager
```

## Install

```sh
meson install -C build
```

## Debian Package

Build a single Debian installer package:

```sh
./packaging/build-deb.sh
```

The package is written to `dist/owl-file-manager_<version>_<architecture>.deb`.
Install it with APT so runtime dependencies are installed automatically:

```sh
sudo apt install ./dist/owl-file-manager_*.deb
```

### Raspberry Pi (Debian Trixie / OwlOS, arm64)

From the project directory on the Pi, run the helper to install build
dependencies, compile the arm64 package, and install it:

```sh
sh packaging/install-pi-arm64.sh
```

The helper checks that the system is arm64 and limits compilation to one job
to reduce memory usage. It creates and installs
`dist/owl-file-manager_<version>_arm64.deb`.

The package declares the Qt Quick and Wayland runtime dependencies required
for the labwc desktop session. You can also copy the generated `.deb` from
`dist/` and install it on another compatible arm64 Trixie system.
