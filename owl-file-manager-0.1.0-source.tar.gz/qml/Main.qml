import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ApplicationWindow {
    id: window
    width: 1060
    height: 700
    minimumWidth: 760
    minimumHeight: 460
    visible: true
    title: qsTr("Owl File Manager") + (fileModel.path ? (" - " + fileModel.path) : "")
    color: palette.window

    property string selectedItemPath: ""
    property string selectedItemName: ""
    property bool selectedItemIsDir: false

    // Keyboard Shortcuts
    Shortcut {
        sequence: "Alt+Left"
        enabled: fileModel.canGoBack
        onActivated: fileModel.goBack()
    }
    Shortcut {
        sequence: "Alt+Right"
        enabled: fileModel.canGoForward
        onActivated: fileModel.goForward()
    }
    Shortcut {
        sequence: "Alt+Up"
        onActivated: fileModel.goUp()
    }
    Shortcut {
        sequence: "F5"
        onActivated: fileModel.refresh()
    }
    Shortcut {
        sequence: "Ctrl+R"
        onActivated: fileModel.refresh()
    }
    Shortcut {
        sequence: "Ctrl+H"
        onActivated: fileModel.setShowHiddenFiles(!fileModel.showHiddenFiles)
    }
    Shortcut {
        sequence: "Ctrl+Shift+N"
        onActivated: newFolderDialog.openDialog()
    }
    Shortcut {
        sequence: "Ctrl+N"
        onActivated: newFileDialog.openDialog()
    }
    Shortcut {
        sequence: "Ctrl+C"
        enabled: selectedItemPath.length > 0
        onActivated: fileModel.copyItem(selectedItemPath)
    }
    Shortcut {
        sequence: "Ctrl+X"
        enabled: selectedItemPath.length > 0
        onActivated: fileModel.cutItem(selectedItemPath)
    }
    Shortcut {
        sequence: "Ctrl+V"
        enabled: fileModel.hasClipboard
        onActivated: fileModel.pasteItem()
    }
    Shortcut {
        sequence: "F2"
        enabled: selectedItemPath.length > 0
        onActivated: renameDialog.openDialog(selectedItemPath, selectedItemName)
    }
    Shortcut {
        sequence: StandardKey.Delete
        enabled: selectedItemPath.length > 0
        onActivated: deleteConfirmDialog.openDialog(selectedItemPath, selectedItemName)
    }

    // Top Navigation & Actions Header
    header: ToolBar {
        implicitHeight: 48
        background: Rectangle {
            color: palette.window
            border.color: palette.mid
            border.width: 1
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 8
            anchors.rightMargin: 8
            spacing: 6

            // Navigation group
            ToolButton {
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                icon.source: "qrc:/icons/arrow-back.svg"
                icon.width: 16
                icon.height: 16
                enabled: fileModel.canGoBack
                ToolTip.visible: hovered
                ToolTip.text: qsTr("Back (Alt+Left)")
                onClicked: fileModel.goBack()
            }

            ToolButton {
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                icon.source: "qrc:/icons/arrow-forward.svg"
                icon.width: 16
                icon.height: 16
                enabled: fileModel.canGoForward
                ToolTip.visible: hovered
                ToolTip.text: qsTr("Forward (Alt+Right)")
                onClicked: fileModel.goForward()
            }

            ToolButton {
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                icon.source: "qrc:/icons/arrow-up.svg"
                icon.width: 16
                icon.height: 16
                ToolTip.visible: hovered
                ToolTip.text: qsTr("Parent Folder (Alt+Up)")
                onClicked: fileModel.goUp()
            }

            ToolButton {
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                icon.source: "qrc:/icons/home.svg"
                icon.width: 16
                icon.height: 16
                ToolTip.visible: hovered
                ToolTip.text: qsTr("Home Folder")
                onClicked: fileModel.goHome()
            }

            ToolButton {
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                icon.source: "qrc:/icons/refresh.svg"
                icon.width: 16
                icon.height: 16
                ToolTip.visible: hovered
                ToolTip.text: qsTr("Refresh (F5)")
                onClicked: fileModel.refresh()
            }

            // Path Address Field
            TextField {
                id: locationField
                Layout.fillWidth: true
                Layout.minimumWidth: 140
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                text: fileModel.path
                selectByMouse: true
                font.pixelSize: 13
                placeholderText: qsTr("Enter path...")
                onAccepted: fileModel.setPath(text)
            }

            Button {
                text: qsTr("Go")
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                font.pixelSize: 13
                onClicked: fileModel.setPath(locationField.text)
            }

            Rectangle {
                width: 1
                Layout.preferredHeight: 22
                Layout.alignment: Qt.AlignVCenter
                color: palette.mid
            }

            // Search in folder
            TextField {
                id: searchField
                Layout.preferredWidth: 160
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                placeholderText: qsTr("Search...")
                text: fileModel.filterText
                selectByMouse: true
                font.pixelSize: 13
                leftPadding: 28
                rightPadding: searchClearBtn.visible ? 26 : 8
                onTextChanged: fileModel.setFilterText(text)

                Image {
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.leftMargin: 8
                    width: 14
                    height: 14
                    source: "qrc:/icons/search.svg"
                    fillMode: Image.PreserveAspectFit
                    opacity: 0.55
                }

                ToolButton {
                    id: searchClearBtn
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    anchors.rightMargin: 2
                    width: 22
                    height: 22
                    visible: searchField.text.length > 0
                    icon.source: "qrc:/icons/clear.svg"
                    icon.width: 10
                    icon.height: 10
                    onClicked: {
                        searchField.text = ""
                        fileModel.setFilterText("")
                    }
                }
            }

            // Action Buttons
            ToolButton {
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                icon.source: "qrc:/icons/folder-new.svg"
                icon.width: 18
                icon.height: 18
                ToolTip.visible: hovered
                ToolTip.text: qsTr("New Folder (Ctrl+Shift+N)")
                onClicked: newFolderDialog.openDialog()
            }

            ToolButton {
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                icon.source: "qrc:/icons/file-new.svg"
                icon.width: 18
                icon.height: 18
                ToolTip.visible: hovered
                ToolTip.text: qsTr("New File (Ctrl+N)")
                onClicked: newFileDialog.openDialog()
            }

            ToolButton {
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                icon.source: fileModel.showHiddenFiles ? "qrc:/icons/eye-visible.svg" : "qrc:/icons/eye-hidden.svg"
                icon.width: 18
                icon.height: 18
                checkable: true
                checked: fileModel.showHiddenFiles
                ToolTip.visible: hovered
                ToolTip.text: fileModel.showHiddenFiles ? qsTr("Hide Hidden Files (Ctrl+H)") : qsTr("Show Hidden Files (Ctrl+H)")
                onClicked: fileModel.setShowHiddenFiles(checked)
            }

            ToolButton {
                id: sortButton
                text: qsTr("Sort ▾")
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                font.pixelSize: 13
                onClicked: sortMenu.open()

                Menu {
                    id: sortMenu
                    y: sortButton.height

                    MenuItem {
                        text: qsTr("Sort by Name") + (fileModel.sortMode === 0 ? (fileModel.sortAscending ? "  (▲ A-Z)" : "  (▼ Z-A)") : "")
                        onTriggered: {
                            if (fileModel.sortMode === 0)
                                fileModel.toggleSortOrder()
                            else {
                                fileModel.setSortMode(0)
                                fileModel.setSortAscending(true)
                            }
                        }
                    }
                    MenuItem {
                        text: qsTr("Sort by Size") + (fileModel.sortMode === 1 ? (fileModel.sortAscending ? "  (▲ Min-Max)" : "  (▼ Max-Min)") : "")
                        onTriggered: {
                            if (fileModel.sortMode === 1)
                                fileModel.toggleSortOrder()
                            else {
                                fileModel.setSortMode(1)
                                fileModel.setSortAscending(true)
                            }
                        }
                    }
                    MenuItem {
                        text: qsTr("Sort by Date") + (fileModel.sortMode === 2 ? (fileModel.sortAscending ? "  (▲ Old-New)" : "  (▼ New-Old)") : "")
                        onTriggered: {
                            if (fileModel.sortMode === 2)
                                fileModel.toggleSortOrder()
                            else {
                                fileModel.setSortMode(2)
                                fileModel.setSortAscending(false)
                            }
                        }
                    }
                    MenuItem {
                        text: qsTr("Sort by Type") + (fileModel.sortMode === 3 ? (fileModel.sortAscending ? "  (▲ Ext)" : "  (▼ Ext)") : "")
                        onTriggered: {
                            if (fileModel.sortMode === 3)
                                fileModel.toggleSortOrder()
                            else {
                                fileModel.setSortMode(3)
                                fileModel.setSortAscending(true)
                            }
                        }
                    }
                }

            }

            ToolButton {
                id: settingsButton
                text: qsTr("Settings")
                Layout.preferredHeight: 32
                Layout.alignment: Qt.AlignVCenter
                font.pixelSize: 13
                onClicked: settingsMenu.open()

                Menu {
                    id: settingsMenu
                    y: settingsButton.height

                    MenuItem {
                        text: qsTr("Change Root Password...")
                        onTriggered: changeRootPasswordDialog.openDialog()
                    }
                }
            }
        }
    }

    // Main Content: SplitView Sidebar & File Listing
    RowLayout {
        anchors.fill: parent
        spacing: 0

        // Left Sidebar: Places
        Rectangle {
            Layout.preferredWidth: 200
            Layout.fillHeight: true
            color: palette.alternateBase

            ColumnLayout {
                anchors.fill: parent
                spacing: 4
                anchors.topMargin: 10
                anchors.bottomMargin: 8
                anchors.leftMargin: 8
                anchors.rightMargin: 8

                Label {
                    text: qsTr("PLACES")
                    font.bold: true
                    font.pixelSize: 11
                    color: palette.placeholderText
                    Layout.leftMargin: 6
                    Layout.bottomMargin: 2
                }

                ListView {
                    id: placesList
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    model: fileModel.quickPlaces()

                    delegate: ItemDelegate {
                        width: placesList.width
                        height: 38
                        highlighted: fileModel.path === modelData.path
                        onClicked: fileModel.setPath(modelData.path)

                        background: Rectangle {
                            radius: 6
                            color: fileModel.path === modelData.path
                                   ? palette.highlight
                                   : (parent.hovered ? Qt.rgba(0, 0, 0, 0.05) : "transparent")
                        }

                        contentItem: RowLayout {
                            spacing: 10
                            anchors.leftMargin: 6
                            anchors.rightMargin: 6

                            Image {
                                Layout.preferredWidth: 20
                                Layout.preferredHeight: 20
                                Layout.alignment: Qt.AlignVCenter
                                source: modelData.iconSource
                                sourceSize.width: 40
                                sourceSize.height: 40
                                fillMode: Image.PreserveAspectFit
                            }
                            Label {
                                Layout.fillWidth: true
                                text: modelData.name
                                elide: Text.ElideRight
                                font.pixelSize: 13
                                font.weight: fileModel.path === modelData.path ? Font.DemiBold : Font.Normal
                                color: fileModel.path === modelData.path ? palette.highlightedText : palette.text
                            }
                        }
                    }
                }
            }
        }

        // Divider
        Rectangle {
            Layout.preferredWidth: 1
            Layout.fillHeight: true
            color: palette.mid
        }

        // Right View: Files & Folders
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 0

            // Header columns
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 34
                color: palette.alternateBase
                border.color: palette.mid
                border.width: 1

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 16
                    anchors.rightMargin: 16
                    spacing: 12

                    // Spacer matching row icon width (24)
                    Item {
                        Layout.preferredWidth: 24
                        Layout.preferredHeight: 24
                    }

                    Label {
                        Layout.fillWidth: true
                        text: qsTr("Name") + (fileModel.sortMode === 0 ? (fileModel.sortAscending ? " ▲" : " ▼") : "")
                        font.bold: true
                        font.pixelSize: 13
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                if (fileModel.sortMode === 0)
                                    fileModel.toggleSortOrder()
                                else {
                                    fileModel.setSortMode(0)
                                    fileModel.setSortAscending(true)
                                }
                            }
                        }
                    }

                    Label {
                        Layout.preferredWidth: 110
                        text: qsTr("Size") + (fileModel.sortMode === 1 ? (fileModel.sortAscending ? " ▲" : " ▼") : "")
                        font.bold: true
                        font.pixelSize: 13
                        horizontalAlignment: Text.AlignRight
                        rightPadding: 8
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                if (fileModel.sortMode === 1)
                                    fileModel.toggleSortOrder()
                                else {
                                    fileModel.setSortMode(1)
                                    fileModel.setSortAscending(true)
                                }
                            }
                        }
                    }

                    Label {
                        Layout.preferredWidth: 170
                        text: qsTr("Modified") + (fileModel.sortMode === 2 ? (fileModel.sortAscending ? " ▲" : " ▼") : "")
                        font.bold: true
                        font.pixelSize: 13
                        horizontalAlignment: Text.AlignLeft
                        leftPadding: 8
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                if (fileModel.sortMode === 2)
                                    fileModel.toggleSortOrder()
                                else {
                                    fileModel.setSortMode(2)
                                    fileModel.setSortAscending(false)
                                }
                            }
                        }
                    }
                }
            }

            // File Listing
            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                ListView {
                    id: fileList
                    anchors.fill: parent
                    clip: true
                    model: fileModel
                    boundsBehavior: Flickable.StopAtBounds
                    ScrollBar.vertical: ScrollBar {}

                    // Background right-click
                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.RightButton
                        z: -1
                        onClicked: bgContextMenu.popup()
                    }

                    delegate: ItemDelegate {
                        id: fileDelegate
                        required property int index
                        required property string name
                        required property string filePath
                        required property bool isDirectory
                        required property string size
                        required property string modified
                        required property string iconSource

                        width: fileList.width
                        height: 40
                        highlighted: ListView.isCurrentItem

                        onClicked: {
                            fileList.currentIndex = index
                            selectedItemPath = filePath
                            selectedItemName = name
                            selectedItemIsDir = isDirectory
                        }

                        onDoubleClicked: {
                            fileModel.openItem(filePath)
                        }

                        MouseArea {
                            anchors.fill: parent
                            acceptedButtons: Qt.RightButton
                            onClicked: {
                                fileList.currentIndex = index
                                selectedItemPath = filePath
                                selectedItemName = name
                                selectedItemIsDir = isDirectory
                                itemContextMenu.popup()
                            }
                        }

                        background: Rectangle {
                            color: fileDelegate.highlighted
                                   ? palette.highlight
                                   : (fileDelegate.hovered ? Qt.rgba(0, 0, 0, 0.04) : (index % 2 === 0 ? "transparent" : Qt.rgba(0, 0, 0, 0.015)))
                        }

                        contentItem: RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: 16
                            anchors.rightMargin: 16
                            spacing: 12

                            Image {
                                Layout.preferredWidth: 24
                                Layout.preferredHeight: 24
                                Layout.alignment: Qt.AlignVCenter
                                source: iconSource
                                sourceSize.width: 48
                                sourceSize.height: 48
                                fillMode: Image.PreserveAspectFit
                                asynchronous: true
                            }

                            Label {
                                Layout.fillWidth: true
                                text: name
                                elide: Text.ElideMiddle
                                font.pixelSize: 13
                                font.weight: isDirectory ? Font.DemiBold : Font.Normal
                                color: fileDelegate.highlighted ? palette.highlightedText : palette.text
                            }

                            Label {
                                Layout.preferredWidth: 110
                                text: size
                                horizontalAlignment: Text.AlignRight
                                rightPadding: 8
                                font.pixelSize: 12
                                color: fileDelegate.highlighted ? palette.highlightedText : palette.placeholderText
                            }

                            Label {
                                Layout.preferredWidth: 170
                                text: modified
                                horizontalAlignment: Text.AlignLeft
                                leftPadding: 8
                                font.pixelSize: 12
                                color: fileDelegate.highlighted ? palette.highlightedText : palette.placeholderText
                            }
                        }
                    }

                    Label {
                        anchors.centerIn: parent
                        visible: fileList.count === 0 && fileModel.errorMessage.length === 0
                        text: fileModel.filterText.length > 0 ? qsTr("No matching files found") : qsTr("This folder is empty")
                        color: palette.placeholderText
                        font.pixelSize: 16
                    }
                }
            }

            // Error banner
            Rectangle {
                Layout.fillWidth: true
                visible: fileModel.errorMessage.length > 0
                color: "#b3261e"
                height: visible ? 40 : 0

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 8
                    Label {
                        Layout.fillWidth: true
                        text: fileModel.errorMessage
                        color: "white"
                        elide: Text.ElideRight
                    }
                    ToolButton {
                        text: "✕"
                        onClicked: fileModel.refresh()
                    }
                }
            }
        }
    }

    // Status Bar (Bottom)
    footer: ToolBar {
        implicitHeight: 32
        background: Rectangle {
            color: palette.window
            border.color: palette.mid
            border.width: 1
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 12

            Label {
                text: qsTr("%1 items (%2 folders, %3 files)")
                    .arg(fileModel.itemCount)
                    .arg(fileModel.folderCount)
                    .arg(fileModel.fileCount)
                font.pixelSize: 12
                color: palette.placeholderText
            }

            Label {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                visible: selectedItemPath.length > 0
                text: qsTr("Selected: %1").arg(selectedItemName)
                font.pixelSize: 12
                color: palette.text
                elide: Text.ElideMiddle
            }

            Item {
                Layout.fillWidth: true
                visible: selectedItemPath.length === 0
            }

            Label {
                text: fileModel.storageFreeSpace
                font.pixelSize: 12
                color: palette.placeholderText
            }
        }
    }

    // Context Menus
    Menu {
        id: itemContextMenu

        MenuItem {
            text: selectedItemIsDir ? qsTr("Open Folder") : qsTr("Open File")
            onTriggered: fileModel.openItem(selectedItemPath)
        }
        MenuSeparator {}
        MenuItem {
            text: qsTr("Copy (Ctrl+C)")
            onTriggered: fileModel.copyItem(selectedItemPath)
        }
        MenuItem {
            text: qsTr("Cut (Ctrl+X)")
            onTriggered: fileModel.cutItem(selectedItemPath)
        }
        MenuItem {
            text: qsTr("Duplicate")
            onTriggered: fileModel.duplicateItem(selectedItemPath)
        }
        MenuSeparator {}
        MenuItem {
            text: qsTr("Rename... (F2)")
            onTriggered: renameDialog.openDialog(selectedItemPath, selectedItemName)
        }
        MenuItem {
            text: qsTr("Delete (Delete)")
            onTriggered: deleteConfirmDialog.openDialog(selectedItemPath, selectedItemName)
        }
        MenuSeparator {}
        MenuItem {
            text: qsTr("Properties")
            onTriggered: propertiesDialog.showForPath(selectedItemPath)
        }
    }

    Menu {
        id: bgContextMenu

        MenuItem {
            text: qsTr("New Folder... (Ctrl+Shift+N)")
            onTriggered: newFolderDialog.openDialog()
        }
        MenuItem {
            text: qsTr("New File... (Ctrl+N)")
            onTriggered: newFileDialog.openDialog()
        }
        MenuItem {
            text: qsTr("Paste (Ctrl+V)")
            enabled: fileModel.hasClipboard
            onTriggered: fileModel.pasteItem()
        }
        MenuSeparator {}
        MenuItem {
            text: qsTr("Show Hidden Files")
            checkable: true
            checked: fileModel.showHiddenFiles
            onTriggered: fileModel.setShowHiddenFiles(checked)
        }
        MenuItem {
            text: qsTr("Open in Terminal")
            onTriggered: fileModel.openTerminal(fileModel.path)
        }
        MenuItem {
            text: qsTr("Refresh (F5)")
            onTriggered: fileModel.refresh()
        }
        MenuSeparator {}
        MenuItem {
            text: qsTr("Folder Properties")
            onTriggered: propertiesDialog.showForPath(fileModel.path)
        }
    }

    // Dialogs
    Dialog {
        id: rootUnlockDialog
        title: qsTr("Restricted Folder")
        width: 360
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        modal: true
        standardButtons: Dialog.Ok | Dialog.Cancel
        property string targetPath: ""

        function openForPath(path) {
            rootUnlockDialog.targetPath = path
            rootPasswordField.text = ""
            rootPasswordError.visible = false
            open()
            rootPasswordField.forceActiveFocus()
        }

        contentItem: ColumnLayout {
            spacing: 12

            Label {
                text: qsTr("Enter the password to access this folder:")
                wrapMode: Text.Wrap
                Layout.fillWidth: true
            }
            TextField {
                id: rootPasswordField
                Layout.fillWidth: true
                echoMode: TextInput.Password
                selectByMouse: true
                onAccepted: rootUnlockDialog.accept()
            }
            Label {
                id: rootPasswordError
                text: qsTr("Incorrect password.")
                color: "#b3261e"
                visible: false
            }
        }

        onAccepted: {
            if (fileModel.unlockRoot(rootPasswordField.text)) {
                fileModel.setPath(rootUnlockDialog.targetPath)
                rootUnlockDialog.targetPath = ""
            } else {
                rootPasswordError.visible = true
                rootPasswordField.selectAll()
                open()
                rootPasswordField.forceActiveFocus()
            }
        }

        onRejected: rootUnlockDialog.targetPath = ""
    }

    Dialog {
        id: changeRootPasswordDialog
        title: qsTr("Change Root Password")
        width: 380
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        modal: true
        standardButtons: Dialog.Ok | Dialog.Cancel

        function openDialog() {
            currentRootPasswordField.text = ""
            newRootPasswordField.text = ""
            confirmRootPasswordField.text = ""
            passwordChangeMessage.text = ""
            open()
            currentRootPasswordField.forceActiveFocus()
        }

        function showMessage(message, isError) {
            passwordChangeMessage.text = message
            passwordChangeMessage.color = isError ? "#b3261e" : "#2e7d32"
            open()
        }

        contentItem: ColumnLayout {
            spacing: 10

            Label {
                text: qsTr("Current password")
            }
            TextField {
                id: currentRootPasswordField
                Layout.fillWidth: true
                echoMode: TextInput.Password
                selectByMouse: true
                onAccepted: newRootPasswordField.forceActiveFocus()
            }
            Label {
                text: qsTr("New password")
            }
            TextField {
                id: newRootPasswordField
                Layout.fillWidth: true
                echoMode: TextInput.Password
                selectByMouse: true
                onAccepted: confirmRootPasswordField.forceActiveFocus()
            }
            Label {
                text: qsTr("Confirm new password")
            }
            TextField {
                id: confirmRootPasswordField
                Layout.fillWidth: true
                echoMode: TextInput.Password
                selectByMouse: true
                onAccepted: changeRootPasswordDialog.accept()
            }
            Label {
                id: passwordChangeMessage
                Layout.fillWidth: true
                wrapMode: Text.Wrap
            }
        }

        onAccepted: {
            const newPassword = newRootPasswordField.text.trim()
            if (currentRootPasswordField.text.length === 0) {
                changeRootPasswordDialog.showMessage(qsTr("Enter your current password."), true)
                return
            }
            if (newPassword.length === 0) {
                changeRootPasswordDialog.showMessage(qsTr("The new password cannot be empty."), true)
                return
            }
            if (newPassword !== confirmRootPasswordField.text.trim()) {
                changeRootPasswordDialog.showMessage(qsTr("The new passwords do not match."), true)
                return
            }
            if (!fileModel.changeRootPassword(currentRootPasswordField.text, newPassword)) {
                changeRootPasswordDialog.showMessage(qsTr("The current password is incorrect."), true)
                return
            }

            currentRootPasswordField.text = ""
            newRootPasswordField.text = ""
            confirmRootPasswordField.text = ""
            changeRootPasswordDialog.showMessage(qsTr("Password changed successfully."), false)
        }
    }

    Dialog {
        id: newFolderDialog
        title: qsTr("New Folder")
        width: 360
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        modal: true
        standardButtons: Dialog.Ok | Dialog.Cancel

        function openDialog() {
            folderNameField.text = qsTr("New Folder")
            open()
            folderNameField.selectAll()
            folderNameField.forceActiveFocus()
        }

        contentItem: ColumnLayout {
            spacing: 12
            Label {
                text: qsTr("Enter name for new folder:")
            }
            TextField {
                id: folderNameField
                Layout.fillWidth: true
                selectByMouse: true
                onAccepted: newFolderDialog.accept()
            }
        }

        onAccepted: {
            if (folderNameField.text.length > 0)
                fileModel.createFolder(folderNameField.text)
        }
    }

    Dialog {
        id: newFileDialog
        title: qsTr("New File")
        width: 360
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        modal: true
        standardButtons: Dialog.Ok | Dialog.Cancel

        function openDialog() {
            newFileNameField.text = qsTr("new_file.txt")
            open()
            newFileNameField.selectAll()
            newFileNameField.forceActiveFocus()
        }

        contentItem: ColumnLayout {
            spacing: 12
            Label {
                text: qsTr("Enter name for new file:")
            }
            TextField {
                id: newFileNameField
                Layout.fillWidth: true
                selectByMouse: true
                onAccepted: newFileDialog.accept()
            }
        }

        onAccepted: {
            if (newFileNameField.text.length > 0)
                fileModel.createFile(newFileNameField.text)
        }
    }

    Dialog {
        id: renameDialog
        title: qsTr("Rename Item")
        width: 360
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        modal: true
        standardButtons: Dialog.Ok | Dialog.Cancel
        property string targetPath: ""

        function openDialog(path, currentName) {
            targetPath = path
            renameField.text = currentName
            open()
            renameField.selectAll()
            renameField.forceActiveFocus()
        }

        contentItem: ColumnLayout {
            spacing: 12
            Label {
                text: qsTr("Enter new name:")
            }
            TextField {
                id: renameField
                Layout.fillWidth: true
                selectByMouse: true
                onAccepted: renameDialog.accept()
            }
        }

        onAccepted: {
            if (renameField.text.length > 0 && targetPath.length > 0)
                fileModel.renameItem(targetPath, renameField.text)
        }
    }

    Dialog {
        id: deleteConfirmDialog
        title: qsTr("Confirm Delete")
        width: 360
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        modal: true
        standardButtons: Dialog.Yes | Dialog.No
        property string targetPath: ""

        function openDialog(path, name) {
            targetPath = path
            deleteLabel.text = qsTr("Are you sure you want to delete '%1'?").arg(name)
            open()
        }

        contentItem: Label {
            id: deleteLabel
            wrapMode: Text.Wrap
            Layout.fillWidth: true
        }

        onAccepted: {
            if (targetPath.length > 0)
                fileModel.deleteItem(targetPath)
        }
    }

    Dialog {
        id: propertiesDialog
        title: qsTr("Properties")
        width: 420
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        modal: true
        standardButtons: Dialog.Close
        property var props: ({})

        function showForPath(path) {
            props = fileModel.getItemProperties(path)
            open()
        }

        contentItem: GridLayout {
            columns: 2
            rowSpacing: 8
            columnSpacing: 16

            Label { text: qsTr("Name:"); font.bold: true }
            Label { text: propertiesDialog.props.name || "" }

            Label { text: qsTr("Type:"); font.bold: true }
            Label { text: propertiesDialog.props.type || "" }

            Label { text: qsTr("Location:"); font.bold: true }
            Label { text: propertiesDialog.props.path || ""; elide: Text.ElideMiddle; Layout.preferredWidth: 260 }

            Label { text: qsTr("Size:"); font.bold: true }
            Label { text: propertiesDialog.props.size || "" }

            Label { text: qsTr("Modified:"); font.bold: true }
            Label { text: propertiesDialog.props.modified || "" }

            Label { text: qsTr("Created:"); font.bold: true }
            Label { text: propertiesDialog.props.created || "" }

            Label { text: qsTr("Permissions:"); font.bold: true }
            Label { text: propertiesDialog.props.permissions || "" }

            Label { text: qsTr("Owner / Group:"); font.bold: true }
            Label { text: (propertiesDialog.props.owner || "") + " / " + (propertiesDialog.props.group || "") }
        }
    }

    Connections {
        target: fileModel
        function onRequestRootPassword(targetPath) {
            rootUnlockDialog.openForPath(targetPath)
        }
        function onPathChanged() {
            locationField.text = fileModel.path
            selectedItemPath = ""
            selectedItemName = ""
            fileList.currentIndex = -1
        }
    }
}
